const fs = require('fs');
const path = require('path');

// 要合并的Markdown文件所在的目录
const sourceDir = path.resolve('/Users/pan9/Downloads/20240620');
// 输出合并后的Markdown文件的路径
const outputFilePath = path.resolve('/Users/pan9/Downloads/20240620.md');

// 读取目录中的所有文件
fs.readdir(sourceDir, (err, files) => {
    if (err) {
        console.error('读取目录时出错:', err);
        return;
    }

    // 过滤出Markdown文件
    const markdownFiles = files.filter(file => path.extname(file) === '.md');
    // 读取并合并Markdown文件内容
    let mergedContent = '';
    for(let i = 0; i < markdownFiles.length; i++) {
        const file = markdownFiles[i]
        const filePath = path.join(sourceDir, file);
        const content = fs.readFileSync(filePath, 'utf8')
        mergedContent += content + '\n---\n'; // 在文件内容之间添加分隔符
    }

    // 所有文件读取完毕后，写入输出文件
    fs.writeFile(outputFilePath, mergedContent, err => {

        console.log(mergedContent)
        if (err) {
            console.error('写入文件时出错:', err);
            return;
        }
        console.log('Markdown文件合并完成');
    });
});