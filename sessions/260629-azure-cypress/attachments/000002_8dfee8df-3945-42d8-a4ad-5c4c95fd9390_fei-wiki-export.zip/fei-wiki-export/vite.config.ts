import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import { loadEnv } from 'vite'

export default ({ mode }) => {
  const env = loadEnv(mode, process.cwd())
  let url = env.VITE_PAGE_BASEURL ? env.VITE_PAGE_BASEURL : env.VITE_SERVER_BASEURL
  return defineConfig({
    server: {
      port: 3800,
      proxy: {
        "/api/feishu": {
          target: "https://open.feishu.cn",
          changeOrigin: true,
          rewrite: (path: string) => {
            return path.replace("/api/feishu", "open-apis");
          }
        },
        "/api/upload": {
          target: "https://kuai.haier.net/api/assembler/file/upload",
          // target: "https://techless.haier.net/api/appcenter/image/upload",
          // target: "http://10.250.2.215:31297/file/upload",
          changeOrigin: true,
          rewrite: (path: string) => {
            return path.replace("/api/upload", "");
          }
        }
      }
    },
    base: url,
    plugins: [vue()]
  })

}
